package com.example.lostfinder.data.model.post

data class PostCreateResponse(
    val id: Long,
    val title: String,
    val content: String,
    val imageUrl: String?,
    val categoryName: String,
    val createdAt: String
)
