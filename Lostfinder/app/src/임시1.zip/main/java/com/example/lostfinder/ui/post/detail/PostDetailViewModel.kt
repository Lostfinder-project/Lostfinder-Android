package com.example.lostfinder.ui.post.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.lostfinder.data.model.post.PostDetailResponse
import com.example.lostfinder.data.repository.PostRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PostDetailViewModel : ViewModel() {

    private val repository = PostRepository()

    private val _state = MutableStateFlow<PostDetailState>(PostDetailState.Loading)
    val state: StateFlow<PostDetailState> = _state

    fun loadPost(id: Long) {
        viewModelScope.launch {
            _state.value = PostDetailState.Loading

            try {
                val response = repository.getPostDetail(id)

                if (response.isSuccessful) {
                    val body = response.body()?.data   // ApiResponse<PostDetailResponse>

                    if (body != null) {
                        _state.value = PostDetailState.Success(body)
                    } else {
                        _state.value = PostDetailState.Error("데이터 없음")
                    }

                } else {
                    _state.value = PostDetailState.Error("서버 오류: ${response.code()}")
                }

            } catch (e: Exception) {
                _state.value = PostDetailState.Error(e.message ?: "알 수 없는 오류")
            }
        }
    }

    sealed class PostDetailState {
        object Loading : PostDetailState()
        data class Success(val data: PostDetailResponse) : PostDetailState()
        data class Error(val msg: String) : PostDetailState()
    }
}
