package com.example.lostfinder.ui.post.list

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.lostfinder.databinding.ItemPostBinding
import com.example.lostfinder.data.model.post.PostListItem

class PostListAdapter(
    private val items: List<PostListItem>
) : RecyclerView.Adapter<PostListAdapter.PostViewHolder>() {

    inner class PostViewHolder(val binding: ItemPostBinding)
        : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val binding = ItemPostBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return PostViewHolder(binding)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val item = items[position]

        holder.binding.textTitle.text = item.title
        holder.binding.textTime.text = item.createdAt

        Glide.with(holder.itemView.context)
            .load(item.imageUrl)
            .into(holder.binding.imagePost)
    }
}
