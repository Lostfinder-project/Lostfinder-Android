package com.example.lostfinder.ui.post.list

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.lostfinder.databinding.ActivityPostListBinding
import com.example.lostfinder.util.collectWhenStarted

class PostListActivity : ComponentActivity() {

    private lateinit var binding: ActivityPostListBinding
    private val viewModel: PostListViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPostListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        observeData()

        viewModel.loadPosts()
    }

    private fun setupRecyclerView() {
        binding.recyclerPosts.layoutManager = LinearLayoutManager(this)
    }

    private fun observeData() {
        viewModel.posts.collectWhenStarted(this) { postList ->
            binding.recyclerPosts.adapter = PostListAdapter(postList)
        }
    }
}
