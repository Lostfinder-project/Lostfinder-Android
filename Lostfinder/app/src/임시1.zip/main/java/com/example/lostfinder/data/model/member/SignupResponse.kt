package com.example.lostfinder.data.model.member


data class SignupResponse(
    val id: Long,
    val username: String,
    val nickname: String,
    val phone: String
)