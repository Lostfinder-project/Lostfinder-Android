package com.example.lostfinder.ui.post.detail

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.lostfinder.R
import com.example.lostfinder.util.collectWhenStarted
import androidx.activity.viewModels


class PostDetailActivity : AppCompatActivity() {

    private val viewModel: PostDetailViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_post_detail)

        val postId = intent.getLongExtra("postId", -1)
        if (postId == -1L) {
            finish()
            return
        }

        val img = findViewById<ImageView>(R.id.imgPost)
        val title = findViewById<TextView>(R.id.textTitle)
        val content = findViewById<TextView>(R.id.textContent)
        val btnContact = findViewById<Button>(R.id.btnContact)

        // 상세 정보 불러오기
        viewModel.loadPost(postId)

        // 화면에 바인딩
        viewModel.state.collectWhenStarted(this) { state ->
            when (state) {
                is PostDetailViewModel.PostDetailState.Success -> {
                    val post = state.data

                    // post.title, post.content, post.imageUrl 이 있다고 가정
                    title.text = post.title
                    content.text = post.content

                    Glide.with(this)
                        .load(post.imageUrl)
                        .into(img)

                    btnContact.setOnClickListener {
                        // TODO: 연락처 API 호출해서 보여주기
                    }
                }

                is PostDetailViewModel.PostDetailState.Error -> {
                    title.text = "오류 발생: ${state.msg}"
                }

                is PostDetailViewModel.PostDetailState.Loading -> {
                    title.text = "로딩 중..."
                }
            }
        }
    }
}
