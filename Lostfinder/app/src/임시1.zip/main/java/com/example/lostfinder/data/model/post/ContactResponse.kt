package com.example.lostfinder.data.model.post

data class ContactResponse(
    val phone: String
)
