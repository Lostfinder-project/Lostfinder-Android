package com.example.lostfinder.data.model.member

data class LoginResponse(
    val token: String
)
