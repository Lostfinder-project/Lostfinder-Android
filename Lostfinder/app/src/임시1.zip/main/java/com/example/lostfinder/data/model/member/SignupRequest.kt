package com.example.lostfinder.data.model.member

data class SignupRequest(
    val username: String,
    val password: String,
    val nickname: String,
    val phone: String
)