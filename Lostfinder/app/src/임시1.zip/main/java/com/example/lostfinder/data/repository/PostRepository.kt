package com.example.lostfinder.data.repository

import com.example.lostfinder.data.model.post.PostDetailResponse
import com.lostfinder.app.data.api.RetrofitInstance
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response

class PostRepository {

    private val api = RetrofitInstance.postApi

    suspend fun getPosts() = api.getPosts()

    suspend fun getPostDetail(id: Long) =
        api.getPostDetail(id)

    suspend fun createPost(image: MultipartBody.Part?, req: RequestBody) =
        api.createPost(image, req)

    suspend fun getContact(id: Long) = api.getContact(id)
}
