package com.example.lostfinder.ui.post.list

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.lostfinder.data.model.post.PostListItem
import com.example.lostfinder.data.repository.PostRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PostListViewModel : ViewModel() {

    private val repo = PostRepository()

    private val _posts = MutableStateFlow<List<PostListItem>>(emptyList())
    val posts: StateFlow<List<PostListItem>> = _posts

    fun loadPosts() {
        viewModelScope.launch {
            val response = repo.getPosts()

            if (response.isSuccessful) {
                _posts.value = response.body()?.data ?: emptyList()
            }
        }
    }
}
