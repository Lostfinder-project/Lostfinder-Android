package com.example.lostfinder.data.model.post

data class PostSummaryResponse(
    val id: Long,
    val title: String,
    val categoryName: String,
    val thumbnailUrl: String?,
    val createdAt: String
)
