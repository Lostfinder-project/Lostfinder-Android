package com.example.lostfinder.data.model.member

data class LoginRequest(
    val username: String,
    val password: String
)
